﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-THpAZSZjhSw9uCu\/cNgP178+Dr5wx2sT80GoJV2kbaY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ZhNZjVGxHet4Hdcc2dY5JT2TXaSEhun6cTIImGfDoFQ=",
      "url": "lib\/editor.css"
    },
    {
      "hash": "sha256-sZWBmZpY5bgktNsCzCMZBgvFj\/s0IzX7rd\/C6g6phrw=",
      "url": "lib\/editor.js"
    },
    {
      "hash": "sha256-oEL8Id4fWmkVplXDaFgyi011nJm+483jM1+eopNdMn0=",
      "url": "lib\/navbar-fixed-left.min.css"
    },
    {
      "hash": "sha256-6kxD17zEoCfVXLyzNd6x\/3Nylpnhyc0ebwvxh6K2tlk=",
      "url": "lib\/navbar-fixed-right.min.css"
    },
    {
      "hash": "sha256-Kl7pUq6V6Yys3iQk2PVYVHLLTLOwCavD+rZX1YuihO8=",
      "url": "lib\/paper.css"
    },
    {
      "hash": "sha256-rGZBDmKmQ53Y2IviciV2sYnA4BWN6PxKxIFRzm78HlY=",
      "url": "lib\/ToolBox.css"
    },
    {
      "hash": "sha256-hTHfDQq40So+eqCxJjB0Kb1XCn908W7Xuf\/iO\/1ZfQY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-O5mTQk2Pa6DYYQnH\/jUkV75pGLfYK9wc0OUSTbDePkw=",
      "url": "resource\/sample-picture.png"
    },
    {
      "hash": "sha256-XY4lbrOO5fOhB\/tkJfj\/EmaA3V5S5VY6wLpBfjI59Dg=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-DdDJozCjjqOfe8KsUHRke1hqWP+pk28sN70hDHW4Rrw=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-Oz6VcnEvOSi9TF9ozqNvwYvugCiM8lkMwZNj9J2BHpA=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-5X2a9XriBABR488+w9neDZKrtj9+7kMNLQT4Psu\/g7g=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-lKqqhxiAd3vzqKzgpLIrNnS39sZANXLyMFRBv7nVUkc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-b6HONu8XHgGK5rnHveBfs9LTRgIEQMWyxq\/+O5kFE+s=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-uPbQosjslZD4CWjN8QaT0rODCKxKez4+p84ET1kx5Sw=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-VczOD5nc+d1CU5ga5ZUV17sZ6\/N\/Ua86EQFFyp3WFCY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-ZnvXuGGuMQB2tWzifseaoE+sbq6D\/wJQjExYgrAu+sw=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-Am7S\/eYJPNBUqMzyRm4tebyahHv+jdS5jTN\/xONEwtk=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-SVP0\/QetFC54vxkbF2HFXPTuByOyplYGOdTQkogwYb4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-4sDxhRGAINpTMXaEiMxjj1M0+JWu8gE3hk\/Fo\/oy+N4=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-QyH3nrvXCfR9DQ2DE9\/kOAfV\/QhTJzvV3SJiTfCZALk=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-KEosfGQB5OfVPxCwqKUy99ZG7wtjZq1ZGA5ueP6tGIQ=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-rY+P+S17XKm5Od1cNA6PcUCoqe56iQPXdDrCH\/62L9o=",
      "url": "_framework\/_bin\/ReportEditor.dll"
    },
    {
      "hash": "sha256-1NqxXFgjmQ8qUtGegk7dms9auLC4fGd7h\/OMTFqTaAQ=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-yK+uVT7lY7IgyO9+UagLCspy9pPHr6u8BZpDd6EE42k=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-lybi4oxGxtednPgehx+\/u8q1cKkiUBlCjC4UK3ZUyFk=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-XkgRqOF0HQv2rBzZB1qOnM44V0qRF0wiuyO9eMtZRxY=",
      "url": "_framework\/_bin\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-oKIK1yZhVYzj3avs10M6sNsdUzlJgxTPl6MUKuyjMuY=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-Wm3BZdqVFcFTiOCuwa+j7OFMWWPGiCZIl02dbcVeO4M=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-ugicI6U74fhTdfg9xA\/W\/zSi+Cn0+EzSDBE\/HAlnNEo=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-7QgQNP9UGmQsehcJzzf1aFSL5tDu\/dp9fhRJ5H9xVQ8=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-8QXnf7\/Qc32LcNf6H+PIaagfKUXy5r6nFoNHrrmLSew=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-JbBui7fmN\/4IW4yH9fszL+uJ75PugcBzePhhWjZFf30=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-PeOLHoTFLrqojnG\/5kpDmMehvmZtZE+EkSkVVsdAK9I=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-TzA+HmcHO5ZblC+Ao4If1XihXRC4ijcadQJ8AbaUaOs=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-YeG+CNiUQi\/vk8S6S6NrOetNwHHsZdKblv2BI\/snIeY=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-UD7QtN0UK068Bb2Eu\/tB9ZV\/hxeL5y9B6RH+QMnL8eM=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-RETqE5BdeelYXdQKWtHNnLOfoonmyMqwoYoodLV\/gvw=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "\/KhRgXnN"
};
