﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-THpAZSZjhSw9uCu\/cNgP178+Dr5wx2sT80GoJV2kbaY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-ZhNZjVGxHet4Hdcc2dY5JT2TXaSEhun6cTIImGfDoFQ=",
      "url": "lib\/editor.css"
    },
    {
      "hash": "sha256-sZWBmZpY5bgktNsCzCMZBgvFj\/s0IzX7rd\/C6g6phrw=",
      "url": "lib\/editor.js"
    },
    {
      "hash": "sha256-oEL8Id4fWmkVplXDaFgyi011nJm+483jM1+eopNdMn0=",
      "url": "lib\/navbar-fixed-left.min.css"
    },
    {
      "hash": "sha256-6kxD17zEoCfVXLyzNd6x\/3Nylpnhyc0ebwvxh6K2tlk=",
      "url": "lib\/navbar-fixed-right.min.css"
    },
    {
      "hash": "sha256-Kl7pUq6V6Yys3iQk2PVYVHLLTLOwCavD+rZX1YuihO8=",
      "url": "lib\/paper.css"
    },
    {
      "hash": "sha256-rGZBDmKmQ53Y2IviciV2sYnA4BWN6PxKxIFRzm78HlY=",
      "url": "lib\/ToolBox.css"
    },
    {
      "hash": "sha256-hTHfDQq40So+eqCxJjB0Kb1XCn908W7Xuf\/iO\/1ZfQY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-O5mTQk2Pa6DYYQnH\/jUkV75pGLfYK9wc0OUSTbDePkw=",
      "url": "resource\/sample-picture.png"
    },
    {
      "hash": "sha256-3tdgDd9w0d3SGLPWNDzKDL8HOvDGN2FiJuWXwLKjn9Q=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-53+03kVPskHRq2XHHXH8XtE8hpK5EIrrs87EESB8xYI=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-bejQRenfgMHkfu2JNoRynIcZ2j1zM49MmoPAmXN01DI=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-mHw3v16CWE90PEpOfoqdWdOBbIxKTf9Tl7CfQ7RVbOQ=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-4LEExRvxV6aRIALh9z1mlVp3uyB1alc83Ov+IBBWpvo=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-6Ep+R9doeBKm35yp3VF+sM+Xi5ZKkCOzgZRGsZEjGyY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-4PfaUAXdwYYJAuSrtQpK2l9ECAaf1klZ2xBs\/Ag1YMs=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-OU5rAIqcVDs0jpAhAMP3lOmplweVJiCqouRLYbZeoKo=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-mm4DWc4e8H806aUURbv7sdoX9csvVodRSSLy77KT\/pU=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-BinNdeLHtES4Mt8WZ3ZNaDMr8Q9H\/+9VQABX55xpwLM=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-qKVI5s6+WS7HrcPKHdwaJ1pIG1MlPAxMoXwqaLbgO\/s=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-sBzf2tjQx3+s1wNBqru7CCqIvF34z2l7gRschJODzOY=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-Hfov3SqmzcOIKtpNJHNvPZqhmvbrcXj0WExlOTl2p8I=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-T18fVIHdzXyGgRhKAGmCxjtRMV2Wv2yfm499J4mAQvE=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-+y28ZyWhC27EuuZZm+Ynomm99+EdtY8OZRerl\/h4eDA=",
      "url": "_framework\/_bin\/ReportEditor.dll"
    },
    {
      "hash": "sha256-R6CuivGrf0pZSEavUQLRNpFMC4duz9K84pAelT\/z9BA=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-aCIrJmy53T26o14QJDKe2lm3SGtphv5AZNXlnwU36FU=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-DTRulrS6XZ\/7Bbr7uRdWyXZKvcIqORxVh6ghPaYpwrM=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-Q3GBSxtEL5jcPtjYgmObITquF3wZ3C6rm3z+YSpn2IE=",
      "url": "_framework\/_bin\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-nioLUL86dBmchqTYXUWku9uNGaFxvkJ4gOiudPUyYK8=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-opuoG+iSBv\/sW6NsZ8p6RToYYuoPd2T0EwHy99vvIqA=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-dF0L6U79CXEREhyfrvOph1YfBnfoXuKCUt9aYSd1rLc=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-uXG6PbKUGqUSIGZWrNulWfL1lEpo6zgHUHsVSoBYIfE=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-pCsm24a0s5fgUjKhRu+Y2R7c51bVWr9QWJeY2DfU8A8=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-xwzKmL8ZKYFfGduRzL8POBvNwIMYxjY64FIQuDihOmw=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-Qb9TeRy+1Nymgl6C0yalWBkoDUlRo5qD5l0eOz3amG4=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-WSrbp\/UhVmQ7Ymb0YCfJpAsNSzTELFuyHD\/Jk6Xw6Kw=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-H5Hcu\/x10bC1z8fWPW8LVEvJM0qp12rAH4kIlnJ7tko=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-DH16AKYjGwUnzUocnC5UP4KKcq7v14Z92LcDlTUzdFs=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Qov1qoq0CA0w+sxejLafU4xBZ5d0cUDy8VGXIUKEiPc=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "4OTOZzJF"
};
