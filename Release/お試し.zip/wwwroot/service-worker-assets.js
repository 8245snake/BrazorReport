﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-qU+KhVPK6oQw3UyjzAHU4xjRmCj3TLZUU\/+39dni9E0=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-THpAZSZjhSw9uCu\/cNgP178+Dr5wx2sT80GoJV2kbaY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fWcxYn1XFVQd0EfZjQGmTOJeOWpNZQ+Xw\/a7iSjL0x0=",
      "url": "lib\/editor.css"
    },
    {
      "hash": "sha256-++YlnXbEQkZyVMASQa5xjw5aNRS4R7yZYtTVtlKs\/uA=",
      "url": "lib\/editor.js"
    },
    {
      "hash": "sha256-oEL8Id4fWmkVplXDaFgyi011nJm+483jM1+eopNdMn0=",
      "url": "lib\/navbar-fixed-left.min.css"
    },
    {
      "hash": "sha256-FnNBOoCH+kSSypfKLM8k4wrdFNHuCUtmb1YXPfBchCY=",
      "url": "lib\/navbar-fixed-right.min.css"
    },
    {
      "hash": "sha256-ZvhnU18x1zoL+Vewx4jMoKLrCa\/HD4WRKUW8SS8+Jbo=",
      "url": "lib\/paper.css"
    },
    {
      "hash": "sha256-rGZBDmKmQ53Y2IviciV2sYnA4BWN6PxKxIFRzm78HlY=",
      "url": "lib\/ToolBox.css"
    },
    {
      "hash": "sha256-hTHfDQq40So+eqCxJjB0Kb1XCn908W7Xuf\/iO\/1ZfQY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-O5mTQk2Pa6DYYQnH\/jUkV75pGLfYK9wc0OUSTbDePkw=",
      "url": "resource\/sample-picture.png"
    },
    {
      "hash": "sha256-aVZKXZ4wQ6HM+bdook0xqP+osFQ+s5K4KJAHbsAdxIA=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-LP6Pt\/NO3pm5BKIPxEcnzojiZDIA1NkU4f+e1FadnXQ=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-wP5Mia00E\/5vuxoTzPCoYVwOgj2nMYMGan\/12vIz\/0Y=",
      "url": "_framework\/_bin\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-jzHgXWAvWMkKIGFjZoT84tbe72E+H7CvTr\/Dryh4QPs=",
      "url": "_framework\/_bin\/Microsoft.Bcl.AsyncInterfaces.dll"
    },
    {
      "hash": "sha256-OYF+yErk2R6lVtB1UaAk3A5AOpqMZPHYEEcgU0iRslw=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-RzWmyLTyBjw\/TEyXPCn25GMQGsntBf476Tov2eXm1fo=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-p90Y1uJsOIVUn1lgYMVUuriT1gv8gQhcxDbkGzQDuis=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-P8sEGYgNxILvdi53vGD+wpWIJ3shcFWajl1ekLMiLMg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-7bmlrqE6PNeIFHmLlcoXBrLBlPFRtRKJYHLahgKcmXI=",
      "url": "_framework\/_bin\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-J0WkGOC4cHfMQ\/nrR3luKLo\/7+x7sqWeGmRqqONhakc=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-5GbUr8R\/cQy8yKL5kZkE5PSqlcnuXvSvqhqOjOlF\/Xg=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-Hpt1lIat6zcZK1JBUiX3bB\/W0iAmmmjxzHF4d6g5iU8=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-JUQoekdRpVa4OlZqMq+H52AkFje4lWtS3QpBL4cn6DE=",
      "url": "_framework\/_bin\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-3cbvJEo8k8VJVQwyEZWWQ6yGRFQW8\/219DaOnmsX3e4=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-zV\/OfJNfNsG404X30Pwkdymdh1KmZpTVEmG\/JNFVc\/k=",
      "url": "_framework\/_bin\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-9\/Xf2EMQPU1kqRhrGfm72ijdaabC5gSzbteNZSz42Uc=",
      "url": "_framework\/_bin\/Mono.Security.dll"
    },
    {
      "hash": "sha256-nJBEhZHJyp4OSsrKtgKpmqNEKjCfz7GnoJF2W9kKlyg=",
      "url": "_framework\/_bin\/mscorlib.dll"
    },
    {
      "hash": "sha256-8+aWlQshkso8ei8xp5J0gn4ZNGRYRMqXzI+osKzgVYI=",
      "url": "_framework\/_bin\/Newtonsoft.Json.dll"
    },
    {
      "hash": "sha256-yeOvqTYFkzpYhxVSYUM6Hy709cUQOBfaqfXrw2sS6UU=",
      "url": "_framework\/_bin\/ReportEditor.dll"
    },
    {
      "hash": "sha256-tjdqllSSpKKdy6hC6+pmy6sExM\/TEThaby9nDNAi2F0=",
      "url": "_framework\/_bin\/System.Core.dll"
    },
    {
      "hash": "sha256-2D5h1ukxLywUfa7Q6TcE5INueKQ53MUP4NLbDGWSKLo=",
      "url": "_framework\/_bin\/System.Data.dll"
    },
    {
      "hash": "sha256-3O+dtck0WDEN38TlWQhX9+Ztpng78XVYZHWiCJIFR50=",
      "url": "_framework\/_bin\/System.dll"
    },
    {
      "hash": "sha256-hkvQpQPBuctjcZPKcsax4ElgOX6gb1rci6KN4RIAerQ=",
      "url": "_framework\/_bin\/System.Drawing.Common.dll"
    },
    {
      "hash": "sha256-T1\/w9h\/K0or8MmshKC\/SOVArCW0Zuj7bMd6Yk3HxMmo=",
      "url": "_framework\/_bin\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-Dr1Iwyi\/QGV\/HQfok+iB0TOncZnIAmd8p\/q9P2gXPVE=",
      "url": "_framework\/_bin\/System.Net.Http.WebAssemblyHttpHandler.dll"
    },
    {
      "hash": "sha256-CS+9LZ8B3bQKP23u2uImq+6b26dM1ULeyAGpeFVuQwc=",
      "url": "_framework\/_bin\/System.Numerics.dll"
    },
    {
      "hash": "sha256-snKdG6e7bmEeCLYy3PPgDgt7k8vAn8y3R9H3TjlIc\/g=",
      "url": "_framework\/_bin\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-\/QcubYTiQbM0uDMu8yt8ehdzs\/Qay71ZaDG9tMGZJTc=",
      "url": "_framework\/_bin\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-7E\/+JyL3PkinchmZa6ubwALxorYziwNdX4d2ghVeT4A=",
      "url": "_framework\/_bin\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-PTKJfi09wdEOnWEy4w+6F0BnTQQ2vWsqTlG0lrQcpbg=",
      "url": "_framework\/_bin\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-Uh4nlsfcrfLe00wXxBP3iUXtMFcG9KQxwK4HGZkt34k=",
      "url": "_framework\/_bin\/System.Xml.dll"
    },
    {
      "hash": "sha256-7\/J12FrpLgaaVsJ77lGJfasaHwbNPujAlnm1n4FhK78=",
      "url": "_framework\/_bin\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-XgkG0mRU06CJmBAk6kyO+U9t3zF7Qj7VTqiWHAYcL8k=",
      "url": "_framework\/_bin\/WebAssembly.Bindings.dll"
    },
    {
      "hash": "sha256-mPoqx7XczFHBWk3gRNn0hc9ekG1OvkKY4XiKRY5Mj5U=",
      "url": "_framework\/wasm\/dotnet.3.2.0.js"
    },
    {
      "hash": "sha256-3S0qzYaBEKOBXarzVLNzNAFXlwJr6nI3lFlYUpQTPH8=",
      "url": "_framework\/wasm\/dotnet.timezones.dat"
    },
    {
      "hash": "sha256-UC\/3Rm1NkdNdlIrzYARo+dO\/HDlS5mhPxo0IQv7kma8=",
      "url": "_framework\/wasm\/dotnet.wasm"
    },
    {
      "hash": "sha256-SPHS1EAPAcMFN4TEIUYl3FWtoCQTsNJch0XVGgok1eE=",
      "url": "_framework\/blazor.webassembly.js"
    },
    {
      "hash": "sha256-Y0q4FuxkTkOoVYlJnrEKe2llhEe+NSnHJ3DvRaA7YOI=",
      "url": "_framework\/blazor.boot.json"
    }
  ],
  "version": "NJBGRr7T"
};
